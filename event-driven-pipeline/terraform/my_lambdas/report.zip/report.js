exports.handler = async (event) => { return "Report generated"; };
